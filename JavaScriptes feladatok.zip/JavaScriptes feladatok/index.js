

function OsszegzesTetele() {
    let tomb = []
    for (let i = 0; i < 10; i++) {
        let randomSzamok = Math.round(Math.random() * 5)
        tomb.push(randomSzamok)
    }

    let osszeg = 0
    for (let i = 0; i < tomb.length; i++) {
        osszeg = osszeg + tomb[i]
    }
    console.log(tomb)
    console.log("A tömbben lévő számok összege: "+osszeg)
}
console.log("Összegzés tétele:")
OsszegzesTetele()





function Kivalogatas(meret) {
    let tomb = []
    for (let i = 0; i < meret; i++) {
        let randomSzamok = Math.round(Math.random() * 50)
        tomb.push(randomSzamok)
    }

    console.log("A tömbben lévő számok: " + tomb)

    let parosSzamok = []
    for (let i = 0; i < tomb.length; i++) {
        if (tomb[i] % 2 == 0) {
            parosSzamok.push(tomb[i])
        }
    }

    return parosSzamok
}
console.log("Páros számok kiválogatva: " + Kivalogatas(5))




function LegnagyobbKozosOszto(szam1, szam2) {
    let lnko = 1
    for (let i = 2; i <= szam1; i++) {
        if (szam1 % i == 0 && szam2 % i == 0) {
            lnko++
        }
    }
    console.log(`${szam1} és ${szam2} legnagyobb közös osztója: `)
    return lnko

}
console.log(LegnagyobbKozosOszto(81, 90))


function Tomb() {
    let tomb = []
    for (let i = 0; i <5; i++) {
        let randomSzamok = Math.round(Math.random() * 10)
        tomb.push(randomSzamok)
    }
    return tomb
}
let szamok = Tomb()
console.log(szamok)
console.log("A tömbben lévő számok: " + szamok)


function Atlagszamitas(vizsgaltTomb){
    let atlag=0
    for(let i=0;i<vizsgaltTomb.length;i++){
        atlag+=vizsgaltTomb[i]
    }
    return Math.round(atlag/vizsgaltTomb.length)
}
console.log("A tömbben lévő számok átlaga: "+Atlagszamitas(szamok))



function MaxErtek(vizsgaltTomb) {
    let maxErtek = vizsgaltTomb[0]
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > maxErtek) {
            maxErtek = vizsgaltTomb[i]
        }
    }
    return maxErtek
}
console.log("A tömbben lévő legnagyobb szám: " + MaxErtek(szamok))


function MaxIndex(vizsgaltTomb) {
    let maxIndex = 0
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] > vizsgaltTomb[maxIndex]) {
            maxIndex = i
        }
    }
    return maxIndex
}
console.log("A tömbben lévő legnagyobb szám index helye: " + MaxIndex(szamok))



function MinErtek(vizsgaltTomb) {
    let minErtek = vizsgaltTomb[0]
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < minErtek) {
            minErtek = vizsgaltTomb[i]
        }
    }
    return minErtek
}
console.log("A tömbben lévő legkisebb szám: " + MinErtek(szamok))




function MinIndex(vizsgaltTomb) {
    let minIndex = 0
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] < vizsgaltTomb[minIndex]) {
            minIndex = i
        }
    }
    return minIndex
}
console.log("A tömbben lévő legkisebb szám index helye: " + MinIndex(szamok))




function Megszamlalas(vizsgaltTomb) {
    let parosDb = 0
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            parosDb++
        }
    }
    return parosDb
}
console.log("A tömbben lévő páros elemek száma: " + Megszamlalas(szamok))



//HALMAZMŰVELETEK & CIKLUS GYAKORLÁS
console.log("//HALMAZMŰVELETEK & CIKLUS FELADATOK")


function Halmazok() {
    let aHalmaz = []
    let bHalmaz = []

    for (let i = 0; i < 5; i++) {
        let randomSzamok = Math.round(Math.random() * 20)
        aHalmaz.push(randomSzamok)
        bHalmaz.push(randomSzamok)
    }
    return [aHalmaz, bHalmaz]
}

let aHalmazSzamok = Halmazok()[0]
let bHalmazSzamok = Halmazok()[1]
console.log("A halmaz elemei: " + aHalmazSzamok)
console.log("B halmaz elemei: " + bHalmazSzamok)


function Unio() {
    let aHalmaz = aHalmazSzamok
    let bHalmaz = bHalmazSzamok
    let unio = []
    for (let i = 0; i < aHalmaz.length; i++) {
        let szerepelE = false
        for (let j = 0; j < unio.length; j++) {
            if (aHalmaz[i] == unio[j]) {
                szerepelE = true
            }
        }
        if (szerepelE == false) {
            unio.push(aHalmaz[i])
        }
    }


    for (let i = 0; i < bHalmaz.length; i++) {
        let szerepelE = false
        for (let j = 0; j < unio.length; j++) {
            if (bHalmaz[i] == unio[j]) {
                szerepelE = true
            }
        }
        if (szerepelE == false) {
            unio.push(bHalmaz[i])
        }
    }
    return unio
}
console.log("UNIO: " + Unio())




function Metszet() {
    let aHalmaz = aHalmazSzamok
    let bHalmaz = bHalmazSzamok
    let metszet = []
    for (let i = 0; i < aHalmaz.length; i++) {
        for (let j = 0; j < bHalmaz.length; j++) {
            if (aHalmaz[i] == bHalmaz[j]) {
                let szerepelE = false
                for (let k = 0; k < metszet.length; k++) {
                    if (aHalmaz[i] == metszet[k]) {
                        szerepelE = true
                    }
                }
                if (szerepelE == false) {
                    metszet.push(aHalmaz[i])
                }
            }
        }
    }
    return metszet
}
console.log("METSZET: " + Metszet())




function AKulB() {
    let aHalmaz = aHalmazSzamok
    let bHalmaz = bHalmazSzamok
    let aKulB = []
    for (let i = 0; i < aHalmaz.length; i++) {
        let vanEgyezes = false
        for (let j = 0; j < bHalmaz.length; j++) {
            if (aHalmaz[i] == bHalmaz[j]) {
                vanEgyezes = true
            }
        }
        if (vanEgyezes == false) {
            let szerepelE = false
            for (let k = 0; k < aKulB.length; k++) {
                if (aHalmaz[i] == aKulB[k]) {
                    szerepelE = true
                }
            }
            if (szerepelE == false) {
                aKulB.push(aHalmaz[i])
            }
        }
    }
    return aKulB
}
console.log("Ami az A-ban benne van de a B-ben nincs: " + AKulB())



function BKulA() {
    let aHalmaz = aHalmazSzamok
    let bHalmaz = bHalmazSzamok
    let bKulA = []
    for (let i = 0; i < bHalmaz.length; i++) {
        let vanEgyezes = false
        for (let j = 0; j < aHalmaz.length; j++) {
            if (bHalmaz[i] == aHalmaz[j]) {
                vanEgyezes = true
            }
        }
        if (vanEgyezes == false) {
            let szerepelE = false
            for (let k = 0; k < bKulA.length; k++) {
                if (bHalmaz[i] == bKulA[k]) {
                    szerepelE = true
                }
            }
            if (szerepelE == false) {
                bKulA.push(bHalmaz[i])
            }
        }
    }
    return bKulA
}
console.log("Ami a B-ben benne van de az A-ban nincs: " + BKulA())



//FÜGGVÉNY & ELJÁRÁS FELADATOK
console.log("//FÜGGVÉNY & ELJÁRÁS FELADATOK")


function ParosParatlan(vizsgaltSzam) {
    if (vizsgaltSzam == 0) {
        return "A szám pontosan nulla"
    }
    else if (vizsgaltSzam % 2 == 0) {
        return "A szám páros"
    }
    else {
        return "A szám páratlan"
    }
}
console.log("Páros vagy páratlan vagy nulla: ")
console.log(ParosParatlan(11))




function PrimE(vizsgaltSzam) {
    let oszto = 0
    for (let i = 1; i <= vizsgaltSzam; i++) {
        if (vizsgaltSzam % i == 0) {
            oszto++
        }
    }
    if (oszto == 2) {
        console.log(`${vizsgaltSzam} prím szám mert az osztójának a száma: ${oszto}`)
    }
    else {
        console.log(`${vizsgaltSzam} NEM prím szám mert az osztójának a száma: ${oszto}`)
    }

}
PrimE(5)



function Koordinata(x, y) {
    if (x > 0 && y > 0) {
        console.log(`${x} és ${y} koordináta az 1. síknegyeden van`)
    }
    else if (x < 0 && y > 0) {
        console.log(`${x} és ${y} koordináta a 2. síknegyeden van`)
    }
    else if (x < 0 && y < 0) {
        console.log(`${x} és ${y} koordináta a 3. síknegyeden van`)
    }
    else if (x > 0 && y < 0) {
        console.log(`${x} és ${y} koordináta a 4. síknegyeden van`)
    }
    else if (x == 0 && y == 0) {
        console.log(`${x} és ${y} koordináta az ORIGÓN van`)
    }
    else if (x == 0) {
        console.log(`${x} és ${y} koordináta az X tengelyen van`)
    }
    else if (y == 0) {
        console.log(`${x} és ${y} koordináta az Y tengelyen van`)
    }
}
Koordinata(-1, 2)



function MelyikANagyobb(szam1, szam2, szam3) {
    if (szam1 > szam2 && szam1 > szam3) {
        console.log(`${szam1} nagyobb mint ${szam2} vagy mint ${szam3}`)
    }
    else if (szam2 > szam1 && szam2 > szam3) {
        console.log(`${szam2} nagyobb mint ${szam1} vagy mint ${szam3}`)
    }
    else if (szam3 > szam1 && szam3 > szam2) {
        console.log(`${szam3} nagyobb mint ${szam2} vagy mint ${szam1}`)
    }
    else if (szam1 == szam2 && szam2 == szam3) {
        console.log(`${szam1} és ${szam2} és ${szam3} ugyanannyi`)
    }
    else if (szam1 == szam2) {
        console.log(`${szam1} és ${szam2} ugyanannyi`)
    }
    else if (szam2 == szam3) {
        console.log(`${szam2} és ${szam3} ugyanannyi`)
    }
}
console.log("Melyik a nagyobb: ")
MelyikANagyobb(16, 22, 9)



function SzorgalomSzovegErtes(jegy) {
    if (jegy == 5) {
        console.log(`${jegy} - Jeles`)
    }
    else if (jegy == 4) {
        console.log(`${jegy} - Jó`)
    }
    else if (jegy == 3) {
        console.log(`${jegy} - Közepes`)
    }
    else if (jegy == 2) {
        console.log(`${jegy} - Elégséges`)
    }
    else {
        alert("Hibás jegy!")
    }
}
SzorgalomSzovegErtes(5)




function TizennyolcPlusz(kor) {
    if (kor < 18 && kor > 0) {
        return false
    }
    else if (kor >= 18) {
        return true
    }
    else {
        return "Hibás kor!"
    }
}
console.log(TizennyolcPlusz(1))




function LegnagyobbKozosOszto(szamEgy, szamKetto) {
    let lnko = 1
    for (let i = 2; i <= szamEgy; i++) {
        if (szamEgy % i == 0 && szamKetto % i == 0) {
            lnko++
        }
    }
    console.log(`${szamEgy} és ${szamKetto} legnagyobb közös osztója: ${lnko}`)
}
LegnagyobbKozosOszto(9, 18)




function SzamtaniSorozatGenerator(elsoElem, kulonbseg, elemSzam) {
    for (let i = 0; i <= elemSzam; i++) {
        console.log(elsoElem + ",")
        elsoElem = elsoElem + kulonbseg
    }
}
SzamtaniSorozatGenerator(2, 2, 5)




console.log("//Logikai prím -e vagy sem függvény:")
function PrimFuggveny(vizsgaltSzam) {
    let oszto = 0
    for (let i = 1; i <= vizsgaltSzam; i++) {
        if (vizsgaltSzam % i == 0) {
            oszto++
        }
    }
    if (oszto == 2) {
        return true
    }
    else {
        return false
    }
}
console.log(PrimFuggveny(5))




console.log("//Páros számokat generáló függvény:")
function ParosGenerator(alsoHatar, felsoHatar) {
    let generaltSzam = Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar)
    if (generaltSzam % 2 == 0) {
        return generaltSzam
    }
    else if (generaltSzam != felsoHatar) {
        return generaltSzam + 1
    }
    else {
        return generaltSzam - 1
    }
}
console.log(ParosGenerator(5, 15))



console.log("//Kettő hatványai elemszámmal ellátva függvény:")
function KettoHatvanyai(elemSzam) {
    for (let i = 1; i <= elemSzam; i++) {
        console.log(2 ** i + ",")
    }
}
KettoHatvanyai(10)




console.log("//Szerkeszthető -e az adott paraméterek alapján a háromszög?")
function SzerkeszthetoHaromszog(aOldal, bOldal, cOldal) {
    if ((aOldal + bOldal > cOldal) && (bOldal + cOldal > aOldal) && (aOldal + cOldal > bOldal)) {
        console.log(`${aOldal} , ${bOldal} , ${cOldal} oldalú háromszög SZERKESZTHETŐ háromszög`)
    }
    else {
        console.log(`${aOldal} , ${bOldal} , ${cOldal} oldalú háromszög NEM szerkeszthető háromszög`)
    }
}
SzerkeszthetoHaromszog(5, 10, 20)
SzerkeszthetoHaromszog(5, 10, 8)




console.log("//Négyzet kerület-terület függvényekre szétbontva:")
function NegyzetKerulet(aOldal) {
    let kerulet = aOldal * 4
    return kerulet
}

function NegyzetTerulet(aOldal) {
    let terulet = aOldal * aOldal
    return terulet
}

function NegyzetKeruletTeruletKiir() {
    let kerulet = NegyzetKerulet(10)
    let terulet = NegyzetTerulet(10)
    console.log(`Négyzet kerülete: ${kerulet}`)
    console.log(`Négyzet területe: ${terulet}`)
}
NegyzetKeruletTeruletKiir()